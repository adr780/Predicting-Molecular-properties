# Exploration

Write here notes about the exploration.